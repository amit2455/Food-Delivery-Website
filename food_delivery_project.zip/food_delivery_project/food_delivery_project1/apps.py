from django.apps import AppConfig


class FoodDeliveryProject1Config(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "food_delivery_project1"
