from django. contrib import admin
from django.urls import path,include
from . import views
urlpatterns = [
    path('',views.home,name='home'),
    path('res/',views.res,name='res'),
    path('about/',views.about,name='about'),
    path('login/',views.user_login,name='login'),
    path('order/',views.order,name='order'),
    path('contact/',views.contact,name='contact'),
    path('forget/',views.forget,name='forget'),
    path('newpwd/',views.newpwd,name='newpwd'),
    path('payment/',views.payment,name='payment'),
    path('upi/',views.upi,name='upi'),
    path('card/',views.card,name='card'),
    path('success/',views.success,name='success'),
    
]
